# Voice Saat Menawarkan Produk
*Pelengkap untuk dokumen Brand Voice & Persona — kursus & konsultasi*

---

## Prinsip Inti

Penawaran adalah **kelanjutan natural dari mengajar**, bukan mode baru. Persona tidak berubah saat menjual — dia tetap "teman yang tahu lebih banyak", cuma sekarang menawarkan jalan yang lebih terstruktur.

Aturan tunggalnya: **tunjukkan kompetensi demi pembaca, jangan pamer demi ego.** Kontennya boleh sama persis (bongkar APK, cerita kasus nyata); yang membedakan cuma *framing* — "mari aku tunjukkan cara kerjanya" vs "lihat betapa hebatnya aku". Pembaca menyimpulkan sendiri kamu kompeten. Itu jauh lebih kuat daripada mengklaimnya.

---

## Voice untuk Kursus

**Posisi:** kamu sudah berbagi gratis; kursus adalah versi yang lebih dalam dan terbimbing untuk yang mau serius.

**Boleh:**
- "Kalau kamu mau belajar ini dari awal sampai bisa, tanpa nyari potongan info ke mana-mana, aku rangkum semuanya di sini."
- "Banyak yang nanya 'mulai dari mana?' — ini jalurnya, urut dari nol."
- "Materi gratisnya ngasih gambaran. Kalau mau praktek beneran sampai paham, ada versi lengkapnya."

**Hindari:**
- ✕ "Daftar sekarang sebelum kehabisan!" — urgensi palsu
- ✕ "Rahasia yang nggak diajarin di tempat lain." — clickbait
- ✕ "Cuma 1% orang yang ngerti ini." — eksklusivitas, melanggar pilar *Empowering*

---

## Voice untuk Konsultasi

**Posisi:** kamu bicara dari pengalaman nyata membereskan masalah serupa, bukan menjual jasa abstrak.

**Boleh:**
- "Ini hal yang sering aku bantu beresin di tim-tim yang aku pegang — kalau kamu lagi ngadepin yang serupa, kita bisa ngobrol."
- "Kemarin aku nemu [kasus nyata]. Kalau di tempatmu ada gejala mirip, mungkin worth dicek bareng."
- "Nggak semua masalah butuh konsultan. Tapi kalau yang ini, biasanya lebih cepet kalau ada yang udah pernah ngalamin."

**Hindari:**
- ✕ "Aku expert security bersertifikat X, Y, Z." — klaim otoritas mentah; biarkan cerita kasus yang bicara
- ✕ "Jangan ambil risiko, serahkan ke profesional." — fear-mongering halus
- ✕ Deretan logo klien tanpa cerita — pamer tanpa nilai untuk pembaca

---

## Tambahan untuk kolom "Hindari"

- ✕ **Scarcity & urgensi palsu** — "sisa 3 slot!", "promo hari ini saja"
- ✕ **Diskon-diskonan agresif** — merusak kredibilitas tenang yang dibangun
- ✕ **Klaim otoritas tanpa bukti** — selalu demonstrasikan lewat cerita, jangan sekadar klaim
- ✕ **Janji hasil instan** — "dijamin jago dalam 7 hari"

---

## Tes Cepat Sebelum Posting

Sebelum publish konten berbau jualan, tanya satu hal:

> *"Apakah kalimat ini membantu pembaca — atau cuma memuji diriku / menakuti mereka?"*

Kalau jawabannya yang kedua, tulis ulang sampai jadi yang pertama.
